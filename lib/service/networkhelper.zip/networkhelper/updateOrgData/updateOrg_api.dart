import 'dart:convert';

import 'package:customstuff/utils/log_print.dart';
import 'package:marketing/model/basic_model.dart';
import 'package:marketing/model/entry_detail_model.dart';
import 'package:marketing/model/login_model.dart';
import 'package:marketing/service/networkhelper/api_provider.dart';

class UpdateOrgAPI {
  static apiCall({
    required EntryDetailModel data,
    required LoginDataModel loginData,
    required String cooperativeCode,
  }) async {
    var body = jsonEncode({
      "ComID": cooperativeCode,
      "UserID": loginData.UID,
      "OrgName": data.orgName,
      "OrgType": data.orgType,
      "Address": data.orgAddress,
      "District": data.orgDistrict,
      "Landline": data.orgLandlineNo,
      "ContactPerson": data.orgContactPerson,
      "Phone": data.mobileNo,
      "PersonContact": data.mobileNo,
      "Email": data.email,
      "PAN": data.orgPAN,
      "Website": data.website,
      "Fb": data.socialMedia,
      "Latitude": data.latitude,
      "Longitude": data.longitude,
      "CurrentSoftware": data.software,
      "CurrentAttend": data.attendanceSystem,
      "CurrentSms": data.smsService,
      "CurrentCloud": data.cloudBackUp,
      "ClientType": data.softwareType,
      "IFlag": data.flag,
      "SourceID": data.leadSource,
      "ProductID": data.leadProduct,
      "LeadStatus": data.leadStatus,
      "LAssignedTo": data.leadStaff,
      "EnquiryDate": data.leadDate,
      "EnquiryTime": data.enquiryTime,
      "LRemarks": data.leadRemark,
      "IsOurClient": 0,
      "QuotePrice": data.quotePrice,
      "FollowType": data.followFor,
      "FollowDate": data.followDate,
      "FollowTime": data.followTime,
      "FollowStatus": 1,
      "FAssignedTo": data.followStaff,
      "FRemarks": data.followRemark,
      "ToType": 1,
      "BranchID": loginData.BranchId,
      "FiscalID": loginData.FiscalId
    });

    CustomLog.log(value: body);
    var jsonData = await APIProvider.postAPI(
      endPoint: "create-org",
      body: body,
    );
    return BasicModel.fromJson(jsonData);
  }
}
