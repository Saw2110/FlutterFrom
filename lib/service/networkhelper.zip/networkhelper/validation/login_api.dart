import 'dart:convert';

import 'package:marketing/model/login_model.dart';
import 'package:marketing/service/networkhelper/api_provider.dart';

class LoginAPI {
  static apiCall({
    required String cooperativeCode,
    required String userName,
    required String password,
    required String mobileToken,
    required String deviceId,
  }) async {
    var body = jsonEncode({
      "ComID": cooperativeCode,
      "UserName": userName,
      "Password": password,
      "NotificationToken": mobileToken,
      "DeviceId": deviceId
    });
    var jsonData = await APIProvider.postAPI(
      endPoint: "login",
      body: body,
    );
    return LoginModel.fromJson(jsonData);
  }
}
