import 'package:marketing/model/dropdown_model.dart';
import 'package:marketing/service/networkhelper/api_provider.dart';

class DropDownAPI {
  static apiCall({
    required String cooperativeCode,
    required String branchId,
    required String departmentId,
    required String subDepartId,
  }) async {
    String endPointValue =
        "master?ComID=$cooperativeCode&BranchID=$branchId&DepartID=$departmentId&SubDepartID=$subDepartId";
    var jsonData = await APIProvider.getAPI(endPoint: endPointValue);
    return DropDownModel.fromJson(jsonData);
  }
}
