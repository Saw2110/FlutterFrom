import 'dart:convert';
import 'dart:io';

import 'package:customstuff/utils/log_print.dart';
import 'package:http/http.dart' as http;
import 'package:marketing/constant/api_constant.dart';

class APIProvider {
  static getAPI({required String endPoint}) async {
    late String api = baseUrl + endPoint;
    try {
      http.Response response = await http.get(Uri.parse(api));
      CustomLog.successLog(value: "API TYPE  => GET ");
      CustomLog.actionLog(value: "Success API  => " + baseUrl + endPoint);
      if (response.statusCode == 200) {
        CustomLog.successLog(
            value: "API Response Value  => " + response.body + "\n\n");
        return jsonDecode(response.body);
      } else {
        CustomLog.errorLog(value: "Error Log  => " + response.body);
        return jsonDecode(response.body);
      }
    } on SocketException {
      return errorNetworkMap;
    } catch (e) {
      return errorMap;
    }
  }

  static postAPI({required String endPoint, required String body}) async {
    late String api = baseUrl + endPoint;

    var headers = {'Content-Type': 'application/json'};
    try {
      http.Response response =
          await http.post(Uri.parse(api), body: body, headers: headers);
      CustomLog.successLog(value: "API TYPE  => POST ");
      CustomLog.actionLog(
          value: "Success API  => " + baseUrl + endPoint + body);

      if (response.statusCode == 200) {
        CustomLog.successLog(
            value: "API Response Value  => " + response.body + "\n\n");
        return jsonDecode(response.body);
      } else {
        CustomLog.errorLog(value: "Error Log  => " + response.body);
        return jsonDecode(response.body);
      }
    } on SocketException {
      return errorNetworkMap;
    } catch (e) {
      return errorMap;
    }
  }
}
